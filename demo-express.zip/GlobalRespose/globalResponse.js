module.exports = function (success, message, payload) {
    return {
      success: success,
      message: message,
      payload: payload,
    };
  };