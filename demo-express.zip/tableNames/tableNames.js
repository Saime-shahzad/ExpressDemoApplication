const tableName = {
    testing: "testing",
   
  };
  
  module.exports = tableName;